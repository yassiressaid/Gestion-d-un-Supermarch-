package march�;

public class Caisse extends Chariot {
	private int numero;
	private double montant;

	public Caisse(int numero, double montant) {
		this.numero = numero;
		this.montant = montant;
	}

	public void scanner(Chariot chariot) {
		
		
		System.out.println("Le ticket de caisse " + chariot);
		
		for (int i = 0; i < chariot.getChariotList().size(); i++) {
			System.out.println(chariot.getCombien().get(i) + " x " + chariot.getChariotList().get(i) + " � "
					+ chariot.getPri().get(i));
		}

		System.out.println("Montant total de chariot " + chariot.getEnsemble() + " MAD");
		
		montant += chariot.getEnsemble();
	}

	public void montantTotal() {

		System.out.println("La caisse " + numero + " a encaiss� " + montant + " MAD");
	}

}
