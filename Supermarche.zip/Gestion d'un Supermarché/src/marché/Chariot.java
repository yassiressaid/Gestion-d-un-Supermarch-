package march�;

import java.util.ArrayList;

public class Chariot {
	private int quantite_achetee;
	private double ensemble;
	private ArrayList<String> chariotList = new ArrayList<String>();
	private ArrayList<Integer> combien = new ArrayList<Integer>();
	private ArrayList<Double> pri = new ArrayList<Double>();

	public ArrayList<Double> getPri() {
		return pri;
	}

	public void setPri(ArrayList<Double> pri) {
		this.pri = pri;
	}

	Chariot() {
	}

	public int getQuantite_achetee() {
		return quantite_achetee;
	}

	public double getEnsemble() {
		return ensemble;
	}

	public void setEnsemble(int ensemble) {
		this.ensemble = ensemble;
	}

	public void setQuantite_achetee(int quantite_achetee) {
		this.quantite_achetee = quantite_achetee;
	}

	public void remplir(Article article, int quantite_achetee) {

//		System.out.println(quantite_achetee + " x " + article.getNom() + " � " + article.getPrix());

		ensemble += quantite_achetee * article.getPrix();

		chariotList.add(article.getNom());

		combien.add(quantite_achetee);
		
		pri.add(article.getPrix());

	}

	public ArrayList<String> getChariotList() {
		return chariotList;
	}

	public ArrayList<Integer> getCombien() {
		return combien;
	}

	public void setCombien(ArrayList<Integer> combien) {
		this.combien = combien;
	}

	public void setChariotList(ArrayList<String> chariotList) {
		this.chariotList = chariotList;
	}

	public void setEnsemble(double ensemble) {
		this.ensemble = ensemble;
	}

}
